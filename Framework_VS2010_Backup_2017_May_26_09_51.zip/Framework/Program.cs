﻿/*
 * Created by Ranorex
 * User: VIGGAS
 * Date: 26/11/2015
 * Time: 14:44
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */

using System;
using System.Threading;
using System.Drawing;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using WinForms = System.Windows.Forms;

using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Reporting;
using Ranorex.Core.Testing;

namespace Framework
{
    class Program
    {
    	private static Framework.Repositories.CQM_Repository repo = Framework.Repositories.CQM_Repository.Instance;
       	//private static Thread dialogWatcher, runner1;
    	public static System.DateTime dateTimeVal;
    	public static PopupWatcher myPopupWatcher = new PopupWatcher();  
    	
        [STAThread]
        public static int Main(string[] args)
        {
           	
			var projectDirectory =   System.IO.Directory.GetParent(System.IO.Directory.GetCurrentDirectory()).Parent.FullName;
			string logFilePath =string.Concat(projectDirectory,"\\AutomationReport\\");
      		string logFileName =string.Concat(logFilePath,string.Format("Test_Case_{0:yyyy-MM-dd_hh-mm-ss-tt}.rxlog", System.DateTime.Now));
       		Report.Setup(ReportLevel.Always, logFileName, true); 
       		dateTimeVal=setDateTime();


			Keyboard.AbortKey = System.Windows.Forms.Keys.Pause;
            int error = 0;

            try
            {
            	 //error = TestSuiteRunner.Run(typeof(Program), Environment.CommandLine);
            	//Watcher = new Thread(ClosePopUpDialogs);
				
            	//myPopupWatcher.WatchAndClick(repo.CampaignNewCampaignMicrosoftDynam.PopUp,repo.CampaignNewCampaignMicrosoftDynam.PopUp.PendingEmailWarningInfo);
	            //myPopupWatcher.Start();
            	error = TestSuiteRunner.Run(typeof(Program), Environment.CommandLine);
	            //runner1=new Thread(StartProg);
	            //runner1.Start();
	            //error = TestSuiteRunner.Run(typeof(Program), Environment.CommandLine);
            }
              catch (ThreadAbortException)
            {            	
                Report.Warn("AbortKey has been pressed");
                Thread.ResetAbort();                
            }

            catch (Exception e)
            {
                Report.Error("Unexpected exception occurred: " + e.ToString());
                Report.Screenshot();

                error = -1;
            }
            return error;



        }
        public static void StartProg()
        {  
        	int error = TestSuiteRunner.Run(typeof(Program), Environment.CommandLine);
        }
        
       
        static void TestSuite_TestSuiteCompleted(object sender, EventArgs e)  
        {  
          ActivityStack.Instance.VisitAll(a => {  
                                            if (a.CustomProperties.ContainsKey("ignore"))  
                                              a.Status = ActivityStatus.Ignored;  
                                            return true;  
                                          });  
        }  
        
        static System.DateTime setDateTime()
        {
        	System.DateTime date = System.DateTime.Now;
        	String dateWithFormat = date.ToString();
			return date;
 
		}
        public static void ClosePopUpDialogs()
        {  
        	Keyboard.AbortKey = System.Windows.Forms.Keys.Pause;
        	
        	try
        	{
//        		while (true)
//	        	{
//					if (repo.CampaignNewCampaignMicrosoftDynam.PopUp.PendingEmailWarningInfo.Exists() )
//					{	
//						Thread.Sleep(300);
//						repo.CampaignNewCampaignMicrosoftDynam.PopUp.PendingEmailWarning.Click();
//					}
//					if (repo.CampaignNewCampaignMicrosoftDynam.PopUp.DontSendInfo.Exists() )
//					{
//						Thread.Sleep(300);
//						repo.CampaignNewCampaignMicrosoftDynam.PopUp.DontSend.Click();
//					}
//					if (repo.CampaignNewCampaignMicrosoftDynam.PopUp.CloseButtonInfo.Exists() )
//					{
//						Thread.Sleep(300);
//						repo.CampaignNewCampaignMicrosoftDynam.PopUp.CloseButton.Click();
//					}
					
					Thread.Sleep(1000);
					
		     	//} 
        	}        	
        	catch (ThreadAbortException)
            {            
                Report.Warn("AbortKey has been pressed");
                Thread.ResetAbort();                
            }        	
        	catch (RanorexException e)
            {
        		// Handles Ranorex exceptions caused
        		// by stopping the automation process
                Report.Error(e.ToString());
                Report.Screenshot();
            }
        }
    }

}
    
    

