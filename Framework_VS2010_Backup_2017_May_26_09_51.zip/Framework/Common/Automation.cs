﻿/*
 * Created by Ranorex
 * User: VIGGAS
 * Date: 26/11/2015
 * Time: 14:45
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;

using Ranorex;

namespace Common
{
	//Common Automation methods
	public class Automation
	{
		 public static void SetText(Ranorex.Text textElement, string value, bool useKeyboard)
        {
            if ( useKeyboard )
            {
                
                textElement.Click();
                Keyboard.Press(value);                
            }
            else
            {
                textElement.TextValue = value;                
            }
            if ( textElement.TextValue != value)
            {
                Report.Failure("Setting text value '" + value + "' failed");
                Report.Screenshot(textElement);
            }
        }
		
		public static void Mouse_Click_ButBegin(Ranorex.Adapter button)
        {
        	if (button.Enabled)
            {
                
		 		button.DoubleClick();
            }
            else
            {
     			Delay.Duration(1000, false);
            	button.DoubleClick();
            }
            
            Report.Log(ReportLevel.Info, "Click", "Button clicked successfully.");
        	
        }

		  
        public static void StartSystemUnderTest(string applicationPath)
        {
            System.Diagnostics.Process.Start(applicationPath);            
        }
        
        public static void KillSystemUnderTest(int processId)
        {    
        
    	    System.Diagnostics.Process procUnderTest = System.Diagnostics.Process.GetProcessById(processId);
    	    Report.Info("Process needs to be killed");
    	    procUnderTest.Kill();
    	    Report.Info("Process killed");            
        }
        public void CloseBrowser()
        {
        	IList<Ranorex.WebDocument> AllDoms = Host.Local.FindChildren<Ranorex.WebDocument>();
			if (AllDoms.Count >=1)
			{
  				foreach (WebDocument myDom in AllDoms)
  				{
     				myDom.Close();
  				}            
			}
        }
    }  
}
