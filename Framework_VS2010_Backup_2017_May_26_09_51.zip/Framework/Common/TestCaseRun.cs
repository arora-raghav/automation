﻿/*
 * Created by Ranorex
 * User: VIGGAS
 * Date: 26/11/2015
 * Time: 14:46
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using Ranorex;
namespace Common
{
	/// <summary>
	/// Description of TestCaseRun.
	/// </summary>
	public class TestCaseRun
    { 
       
        public void Start()
        {
            Report.Info("TEST CASE", "-------------- Testcase '" + this.GetType().ToString() + "' started ---------------");
        	
        }
        public void End()
        {
            Report.Success("TEST CASE","-------------- Testcase '" + this.GetType().ToString() + "' finished -------------");
        	
        }
    }
}
