package strategyPattern;

import org.openqa.selenium.WebDriver;

public class VoiceSearch implements SearchStrategy{

	@Override
	public void search(String text) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setDriver(WebDriver driver) {
		// TODO Auto-generated method stub
		
	}

}
