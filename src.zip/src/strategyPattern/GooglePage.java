package strategyPattern;

import org.openqa.selenium.WebDriver;

public class GooglePage {

	WebDriver driver;
	SearchStrategy strategy;
    public GooglePage(WebDriver driver, SearchStrategy strategy) {

        this.driver = driver;
        this.strategy = strategy;
        this.strategy.setDriver(driver);
        //navigate to google page
        driver.get("https://www.google.com");
    }
    
    public void search(String text)
    {
    	this.strategy.search(text);
    }
}
