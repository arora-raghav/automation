package strategyPattern;

import org.openqa.selenium.WebDriver;

public class GooglePageTest {

	static WebDriver driver = null;
	public static void main(String[] args) {
		GooglePage google = new GooglePage(driver, new TextSearch());
		google.search("Check Price");
	}
}
