package strategyPattern;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class TextSearch implements SearchStrategy{

	@FindBy(id="lst-ib")
	WebElement searchBox;
	
	@FindBy(id="_gs")
	WebElement searchButton;
	
	WebDriver driver;
	@Override
	public void search(String text) {
		// TODO Auto-generated method stub
		searchBox.sendKeys(text);
		searchButton.click();
	}

	@Override
	public void setDriver(WebDriver driver) {
		// TODO Auto-generated method stub
		this.driver = driver;
	}

}
