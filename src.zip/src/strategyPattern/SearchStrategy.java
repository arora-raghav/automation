package strategyPattern;

import org.openqa.selenium.WebDriver;

public interface SearchStrategy {

	public void search(String text);
	public void setDriver(WebDriver driver);
}
	