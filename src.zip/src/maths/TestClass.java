package maths;

public class TestClass {

	public static void main(String[] args) {
        double principal = 51020400;
        double years = 1;
        double rate = 36;

        double r = (rate / 100) / 12;   // monthly interest rate
        double n = 12 * years;          // number of months

        double payment  = (principal * r) / (1 - Math.pow(1+r, -n));
        double interest = payment * n - principal;

        System.out.println("Monthly payments = " + payment);
        System.out.println("Total interest   = " + interest);

	}
}
