package create_FactoryPattern;

import org.openqa.selenium.WebDriver;

public class FactoryTest {
	public void test() {
		DriverManager driverManager = new BrowserManager();
		WebDriver driver = driverManager.createInstance("firefox");
	}
}