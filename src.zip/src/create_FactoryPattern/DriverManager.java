package create_FactoryPattern;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;

public abstract class DriverManager {

	public WebDriver createInstance(String browser)
	{
		WebDriver driver = this.getDriver(browser);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30l, TimeUnit.SECONDS);
		return driver;
	}
	public abstract WebDriver getDriver(String browser);
	
}
