package keyEvents;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.util.Iterator;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class KeyConfig {
	 static JsonObject jsonObject = null;

	public static void main(String[] args) {

		JsonParser parser = new JsonParser();

		int age = 0;
        try {

            Object obj = parser.parse(new FileReader("C:\\temp\\abc.json"));
                        
            JsonArray jsonArray = (JsonArray) obj;
            jsonArray.forEach(e -> 
            {
            	if(e.getAsJsonObject().get("title").getAsString().equals("Controlling High Blood Pressure"))
            	{
            		jsonObject = e.getAsJsonObject();
            	}
            }
            );
           
            	if (age < 19)
                {
            		JsonObject jsonObject2 = jsonObject.get("values").getAsJsonObject();
            		System.out.println(jsonObject2.get("Date of Last BP Reading").getAsString());
                }
            	
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } 

	}
	
	
}