package keyEvents;

public class MultiThreading_CreatingThreads implements Runnable{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		for(int i =0;i<=5;i++)
		{
		
		System.out.println("Running Thread " + i);
		try {
			Thread.sleep(1000l);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		}
	}
public static void main(String[] args) {
	MultiThreading_CreatingThreads mt = new MultiThreading_CreatingThreads();
	mt.run();
}
}
