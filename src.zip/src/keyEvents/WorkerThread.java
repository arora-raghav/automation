package keyEvents;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class WorkerThread implements Runnable{
	
	String no;
	public WorkerThread(String string)
	{
		this.no=string;
	}
	
	public void run ()
	{
		// TODO Auto-generated method stub
			System.out.println("Running : " + no);
			processmessage();
	        System.out.println(Thread.currentThread().getName()+" (End)");//prints thread name  

//			System.out.println("running thread name is:"+Thread.currentThread().getName());  
//			   System.out.println("running thread priority is:"+Thread.currentThread().getPriority());  
//			try {
//				Thread.sleep(2000l);
//			} catch (InterruptedException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
	}
	 private void processmessage() {  
	        try {  Thread.sleep(2000);  } catch (InterruptedException e) { e.printStackTrace(); }  
	    }  
	public static void main(String[] args) {

        ExecutorService executor = Executors.newFixedThreadPool(5);//creating a pool of 5 threads  
        for (int i = 0; i < 10; i++) {  
            Runnable worker = new WorkerThread("" + i);  
            executor.execute(worker);//calling execute method of ExecutorService  
          }  
        executor.shutdown();  
        
        while (!executor.isTerminated()) {   }  
  
        System.out.println("Finished all threads");  
    }  		
//		MultiThreading_CreateThread thread2 = new MultiThreading_CreateThread();
//		MultiThreading_CreateThread thread3 = new MultiThreading_CreateThread();
//		thread1.setPriority(Thread.MIN_PRIORITY);
//		thread2.setPriority(Thread.MAX_PRIORITY);
//		thread1.setDaemon(true);
//		thread1.start();
		
		/*try {
			thread1.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
//		thread2.start();
//		thread3.start();
//		Thread th = new Thread(new MultiThreading_CreateThread ());
//		th.start();
		//		thread1.run();
		//		thread2.run();
	}
