package create_Singelton;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class WebDriverSingleTon {

	    private static WebDriver driver;
	    private static WebDriverSingleTon instance=null;

	    public WebDriver openBrowser(){
	        if (driver == null) {

	        driver=new FirefoxDriver();

	        }
	        driver.manage().window().maximize();
	        return driver;
	    }

public static WebDriverSingleTon getInstance(){
    if(instance==null){
        instance = new WebDriverSingleTon();
    }
    return instance;
}

}
