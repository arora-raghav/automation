package searchAlgos;

import java.util.Scanner;

public class Problem1 {

    public static void main(String args[] ) throws Exception {
        
    	Scanner s = new Scanner(System.in);
        int n = s.nextInt();
        int m = s.nextInt();
        long arr[] = new long[n];
        for(int i = 0; i < n; i++){
            arr[i] = s.nextLong();
        }
        //Arrays.sort(arr);
        long sum = 0, max = Integer.MIN_VALUE;
        for(int i = 0; i <n ; i++){
            sum+= arr[i];
            if(arr[i] > max){
                max = arr[i];
            }
        }
        long ans = 0;
        long st = max, end = sum;
        while(st <= end){
            long mid = (st + end)/2, count = 0, crntSum = 0;
            for(int i = 0; i < n; i++){
                crntSum += arr[i];
                if(crntSum > mid){
                    i--;
                    count++;
                    crntSum = 0;
                }
                if(i == n - 1 && crntSum <= mid){
                    count++;
                }
            }
            if(count <= m){
                ans = mid;
                end = mid - 1;
            }
            else{
                //ans = mid;
                st = mid + 1;
            }
        }
        System.out.println(ans);
    }
}
