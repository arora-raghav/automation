package searchAlgos;

import java.util.Scanner;

public class BinarySearch {

	
	public static void main(String[] args) {
		
		
		Scanner scan = new Scanner(System.in);
		int i = scan.nextInt();		
		int []arr = {10,12,23,34,45,65,78,98};
		BinarySearch search = new BinarySearch();
		System.out.println(search.binarySearchRecursive(arr, i, 0, arr.length-1));
	}
	
	public int binarySearchRecursive(int arr[], int x, int left, int right)
	{
		int mid = left + ((right-left)/2);
		int sum=0;
		if(left> right)
			return 0;
		else if (arr[mid]>x)
			return binarySearchRecursive(arr, x, left, mid-1);
		else if (arr[mid]<x)
			return binarySearchRecursive(arr, x, mid+1, right);
		else if(arr[mid]==x)
		{
			for(int i=0;i<=mid;i++)
			{
				sum = sum+arr[i];
			}
			return sum;
		}
			return 0;
	}
}
