package queue;

public class Queue {

	int arr[]= new int[5];
	int size;
	int front;
	int rear;
	
	public void enqueue(int value)
	{
		
		if(!isFull())
		{
			arr[front] = value;
			front++;
			size++;			
		}
		else
		{
			System.out.println("Couldn't add anything in full queue");
		}
	}
	
	public void dequeue()
	{
		if(!isEmpty())
		{
			size--;
			rear--;			
		}
		else
		{
			System.out.println("Couldn't remove anythine from empty queue");
		}
	}

	public void show()
	{
		for(int i=0;i<size;i++)
		{
			System.out.println(arr[i]);
		}
	}
	public int getSize()
	{
		return this.size;
	}
	
	public boolean isEmpty()
	{
		return getSize()==0;
	}
	
	public boolean isFull()
	{
		return getSize()==5;
	}
	
	
}
