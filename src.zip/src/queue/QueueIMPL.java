package queue;

public class QueueIMPL {

	public static void main(String[] args) {
		
		Queue que = new Queue();
		que.enqueue(10);
		que.enqueue(20);
		que.dequeue();
		que.show();
	}
}
